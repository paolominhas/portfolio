import React from 'react';

export default function SettingsPage() {
  return (
    <div className="flex h-screen w-full bg-zinc-950 text-zinc-50 font-sans selection:bg-zinc-800">
      
      {/* Sidebar */}
      <aside className="w-64 border-r border-zinc-800 flex flex-col">
        <div className="p-6">
          <h2 className="text-lg font-semibold tracking-tight">Settings</h2>
        </div>
        <nav className="flex-1 px-4 space-y-1">
          <a href="#" className="block px-3 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-50 rounded-md hover:bg-zinc-800/50 transition-colors">
            Integrations
          </a>
          <a href="#" className="block px-3 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-50 rounded-md hover:bg-zinc-800/50 transition-colors">
            Setup
          </a>
          {/* Active Item */}
          <a href="#" className="block px-3 py-2 text-sm font-medium bg-zinc-800/50 text-zinc-50 rounded-md">
            General
          </a>
          <a href="#" className="block px-3 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-50 rounded-md hover:bg-zinc-800/50 transition-colors">
            Email
          </a>
          <a href="#" className="block px-3 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-50 rounded-md hover:bg-zinc-800/50 transition-colors">
            Team
          </a>
          <a href="#" className="block px-3 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-50 rounded-md hover:bg-zinc-800/50 transition-colors">
            Billing
          </a>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-y-auto">
        
        {/* Header / Breadcrumbs */}
        <header className="px-8 py-6 border-b border-zinc-800/50">
          <div className="text-sm font-medium text-zinc-400 flex items-center gap-2">
            <span className="hover:text-zinc-200 cursor-pointer transition-colors">Home</span>
            <span>/</span>
            <span className="text-zinc-200">Settings</span>
          </div>
          <h1 className="text-3xl font-semibold tracking-tight mt-2">Settings</h1>
        </header>

        {/* Content Box */}
        <div className="p-8 max-w-4xl">
          
          <div className="border border-zinc-800 rounded-xl bg-zinc-900/30 overflow-hidden">
            
            {/* Section Header */}
            <div className="px-6 py-5 border-b border-zinc-800">
              <h3 className="text-lg font-medium text-zinc-100">General</h3>
            </div>

            {/* Form Area */}
            <div className="p-6 space-y-6">
              
              {/* Store Name Input */}
              <div className="space-y-2">
                <label htmlFor="store-name" className="text-sm font-medium text-zinc-200">
                  Store Name
                </label>
                <input
                  id="store-name"
                  type="text"
                  defaultValue="Acme Corp"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-md px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-700 focus:border-zinc-700 transition-all"
                />
              </div>

              {/* Store Description Input */}
              <div className="space-y-2">
                <label htmlFor="store-description" className="text-sm font-medium text-zinc-200">
                  Store Description
                </label>
                <textarea
                  id="store-description"
                  rows={4}
                  placeholder="Enter a description for your store..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-md px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-700 focus:border-zinc-700 transition-all resize-none"
                />
              </div>

            </div>

            {/* Action Footer */}
            <div className="px-6 py-4 bg-zinc-900/50 border-t border-zinc-800 flex justify-end">
              <button className="bg-zinc-50 text-zinc-950 hover:bg-zinc-200 px-4 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-zinc-500 focus:ring-offset-2 focus:ring-offset-zinc-900">
                Save
              </button>
            </div>

          </div>

        </div>
      </main>
      
    </div>
  );
}