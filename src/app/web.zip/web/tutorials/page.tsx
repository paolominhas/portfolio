"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { tutorials } from "@/data/web-data";

const difficultyColour = {
  beginner: "text-green-400 bg-green-400/10 border-green-400/20",
  intermediate: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  advanced: "text-red-400 bg-red-400/10 border-red-400/20",
};

export default function TutorialsIndex() {
  return (
    <section className="pt-32 pb-20 px-6 md:px-20 max-w-4xl mx-auto">
      <motion.h1
        className="text-4xl md:text-6xl font-bold tracking-tight text-white mb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Tutorials
      </motion.h1>
      <motion.p
        className="text-lg text-zinc-400 mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        From first install to production deployment.
      </motion.p>

      <div className="space-y-4">
        {tutorials.map((tut, i) => (
          <motion.div
            key={tut.slug}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + i * 0.06 }}
          >
            <Link
              href={`/tutorials/${tut.slug}`}
              className="group flex items-start gap-6 p-6 rounded-xl bg-zinc-900/40 border border-white/5 hover:border-[var(--accent-border)] transition-all"
            >
              <span
                className={`shrink-0 text-xs font-mono px-2 py-1 rounded border ${difficultyColour[tut.difficulty]}`}
              >
                {tut.difficulty}
              </span>
              <div>
                <h2 className="text-xl font-semibold group-hover:text-[var(--accent)] transition-colors">
                  {tut.title}
                </h2>
                <p className="text-zinc-400 mt-1">{tut.description}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
