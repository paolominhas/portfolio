"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { webProjects } from "@/data/web-data";
import { ArrowUpRight } from "lucide-react";

export default function WebPortfolio() {
  return (
    <section className="pt-32 pb-20 px-6 md:px-20 max-w-7xl mx-auto">
      <motion.h1
        className="text-4xl md:text-6xl font-bold tracking-tight text-white mb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Portfolio
      </motion.h1>
      <motion.p
        className="text-lg text-zinc-400 mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        Websites designed, built, and managed.
      </motion.p>

      <div className="grid grid-cols-1 gap-8">
        {webProjects.map((project, i) => (
          <motion.div
            key={project.slug}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + i * 0.1 }}
          >
            <Link
              href={`/portfolio/${project.slug}`}
              className="group block rounded-2xl bg-zinc-900/50 border border-white/10 hover:border-[var(--accent-border)] transition-all duration-300 overflow-hidden"
            >
              {/* Image placeholder - replace with actual screenshots */}
              <div className="aspect-video bg-zinc-800/50 flex items-center justify-center text-zinc-600">
                Screenshot: {project.url}
              </div>
              <div className="p-8">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-2xl font-bold group-hover:text-[var(--accent)] transition-colors">
                    {project.title}
                  </h2>
                  <a
                    href={project.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-zinc-500 hover:text-[var(--accent)] transition-colors"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ArrowUpRight size={20} />
                  </a>
                </div>
                <p className="text-zinc-400 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs font-mono text-zinc-500 bg-zinc-800/50 px-2 py-1 rounded"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
